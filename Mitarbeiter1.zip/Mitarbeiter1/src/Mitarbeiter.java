	// Superklasse
public class Mitarbeiter {
	String name, vorname;
	
	public void schreibeMitarbeiter() {
		System.out.println("Name:    "+name);
		System.out.println("Vorname: "+vorname);
	}
}
