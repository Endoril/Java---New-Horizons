	// Subklasse 3
public class Praktikant extends Mitarbeiter {
    double pauschale = 0.0;

    public void schreibePraktikant() {
        schreibeMitarbeiter();
        System.out.println("Pauschale: " + pauschale);
    }
}
