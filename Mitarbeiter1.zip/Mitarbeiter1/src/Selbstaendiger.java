	// Subklasse 2
public class Selbstaendiger extends Mitarbeiter {
	double stundensatz=0.0;
	
	public void schreibeSelbstaendiger () {
		schreibeMitarbeiter();
		System.out.println("Stundensatz: "+stundensatz);
	}
}
