	// Subklasse 4
public class Angestellter extends Mitarbeiter{
	double gehalt=0.0;
	
	public void schreibeAngestellter() {
		schreibeMitarbeiter();
		System.out.println("Gehalt: "+gehalt);
	}
}
