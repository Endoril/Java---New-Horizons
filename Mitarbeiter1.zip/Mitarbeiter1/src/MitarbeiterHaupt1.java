
public class MitarbeiterHaupt1 {

	public static void main(String[] args) {
		// Anlegen u. Belegen eines Angestellten:
		System.out.println("Angestellte(r):");
		Angestellter an1 = new Angestellter();
		an1.name = "Meier";
		an1.vorname = "Emilia";
		an1.gehalt = 3000.0;
		an1.schreibeAngestellter();
		
		// Anlegen u. Belegen eines Selbständigen:
		System.out.println("\nSelbstaendige(r):");
		Selbstaendiger sb1 = new Selbstaendiger();
		sb1.name = "Mueller";
		sb1.vorname = "Hans";
		sb1.stundensatz = 30.0;
		sb1.schreibeSelbstaendiger();
		
		// Anlegen und Belegen eines Praktikanten 1:
        System.out.println("\nPraktikant 1:");
        Praktikant pr1 = new Praktikant();
        pr1.name = "Schulz";
        pr1.vorname = "Max";
        pr1.pauschale = 500.0;
        pr1.schreibePraktikant();

        // Anlegen und Belegen eines Praktikanten 2:
        System.out.println("\nPraktikant 2:");
        Praktikant pr2 = new Praktikant();
        pr2.name = "Becker";
        pr2.vorname = "Anna";
        pr2.pauschale = 600.0;
        pr2.schreibePraktikant();
	}

}
